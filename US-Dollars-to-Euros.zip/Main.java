class Main 
{  
  public static void main(String[] args) {
 double USDollars = 7;
 double conv = .85;
 double total = USDollars * conv;

 System.out.println("Your total Euros are " + total + " and your total USDollars are " + USDollars);
  }
}